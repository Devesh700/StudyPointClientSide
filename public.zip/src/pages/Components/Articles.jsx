import React from 'react'

const Articles = () => {
  return (
    <div>
      
    </div>
  )
}

export default Articles
